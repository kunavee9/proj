terraform init
terraform plan
terraform apply
terraform validate
terraform fmt
